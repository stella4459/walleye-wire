const express = require("express");
const Database = require("better-sqlite3");
const fetch = require("node-fetch");
const path = require("path");
const cron = require("node-cron");

const app = express();
const db = new Database("walleye.db");
const PORT = process.env.PORT || 3000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "walleye2025";
const ANTHROPIC_KEY = process.env.ANTHROPIC_API_KEY || "";

// ── Database ───────────────────────────────────────────────────────────────────
db.exec(`
  CREATE TABLE IF NOT EXISTS stories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    headline TEXT NOT NULL,
    category TEXT NOT NULL,
    source_tag TEXT DEFAULT 'General',
    summary TEXT,
    body TEXT,
    story_date TEXT,
    source_name TEXT,
    source_url TEXT,
    is_council INTEGER DEFAULT 0,
    council_votes TEXT DEFAULT '[]',
    created_at INTEGER DEFAULT (strftime('%s','now'))
  );
  CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    event_date TEXT NOT NULL,
    event_time TEXT,
    location TEXT,
    description TEXT,
    submitted_by TEXT,
    source TEXT DEFAULT 'Community',
    approved INTEGER DEFAULT 0,
    created_at INTEGER DEFAULT (strftime('%s','now'))
  );
  CREATE TABLE IF NOT EXISTS seen_docs (
    url TEXT PRIMARY KEY,
    seen_at INTEGER DEFAULT (strftime('%s','now'))
  );
  CREATE TABLE IF NOT EXISTS weather_cache (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    data TEXT DEFAULT '{}',
    updated_at INTEGER DEFAULT 0
  );
  INSERT OR IGNORE INTO weather_cache (id, data, updated_at) VALUES (1, '{}', 0);
`);

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

function requireAdmin(req, res, next) {
  if (req.headers["x-admin-password"] !== ADMIN_PASSWORD)
    return res.status(401).json({ error: "Unauthorized" });
  next();
}

// ── Claude ─────────────────────────────────────────────────────────────────────
async function callClaude(messages, system, useWebSearch = false) {
  const tools = useWebSearch ? [{ type: "web_search_20250305", name: "web_search" }] : undefined;
  let msgs = [...messages];
  for (let i = 0; i < 8; i++) {
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": ANTHROPIC_KEY,
        "anthropic-version": "2023-06-01",
        "anthropic-beta": "web-search-2025-03-05",
      },
      body: JSON.stringify({ model: "claude-sonnet-4-20250514", max_tokens: 2000, system, messages: msgs, ...(tools ? { tools } : {}) }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error?.message || "Claude API error");
    const text = data.content.filter(b => b.type === "text").map(b => b.text).join("\n");
    if (data.stop_reason === "end_turn") return text;
    if (data.stop_reason === "tool_use") {
      const tu = data.content.filter(b => b.type === "tool_use");
      msgs = [...msgs, { role: "assistant", content: data.content }, { role: "user", content: tu.map(t => ({ type: "tool_result", tool_use_id: t.id, content: "Search executed." })) }];
      continue;
    }
    if (text) return text;
    break;
  }
  throw new Error("No response from Claude.");
}

function parseArr(raw) {
  try { const c = raw.replace(/```json|```/g, "").trim(); return JSON.parse(c.slice(c.indexOf("["), c.lastIndexOf("]") + 1)); } catch { return []; }
}
function parseObj(raw) {
  try { const c = raw.replace(/```json|```/g, "").trim(); return JSON.parse(c.slice(c.indexOf("{"), c.lastIndexOf("}") + 1)); } catch { return null; }
}

// ── Weather ────────────────────────────────────────────────────────────────────
async function refreshWeather() {
  try {
    const r = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=41.5134&longitude=-82.9379&current=temperature_2m,weathercode,windspeed_10m,relativehumidity_2m&daily=temperature_2m_max,temperature_2m_min,weathercode,precipitation_sum&temperature_unit=fahrenheit&wind_speed_unit=mph&precipitation_unit=inch&timezone=America%2FNew_York&forecast_days=5`);
    const data = await r.json();
    db.prepare("UPDATE weather_cache SET data=?, updated_at=? WHERE id=1").run(JSON.stringify(data), Math.floor(Date.now() / 1000));
    console.log("[Weather] Updated.");
  } catch (e) { console.error("[Weather]", e.message); }
}

app.get("/api/weather", async (req, res) => {
  const row = db.prepare("SELECT * FROM weather_cache WHERE id=1").get();
  if (Math.floor(Date.now() / 1000) - (row?.updated_at || 0) > 3600 || row?.data === "{}") await refreshWeather();
  try { res.json(JSON.parse(db.prepare("SELECT data FROM weather_cache WHERE id=1").get().data)); } catch { res.json({}); }
});

// ── Stories ────────────────────────────────────────────────────────────────────
app.get("/api/stories", (req, res) => {
  const { category } = req.query;
  const q = category && category !== "All"
    ? db.prepare("SELECT * FROM stories WHERE category=? ORDER BY created_at DESC LIMIT 100")
    : db.prepare("SELECT * FROM stories ORDER BY created_at DESC LIMIT 100");
  const rows = category && category !== "All" ? q.all(category) : q.all();
  res.json(rows.map(r => ({ ...r, council_votes: JSON.parse(r.council_votes || "[]") })));
});

app.delete("/api/stories/:id", requireAdmin, (req, res) => {
  db.prepare("DELETE FROM stories WHERE id=?").run(req.params.id);
  res.json({ ok: true });
});

app.post("/api/stories/submit", requireAdmin, async (req, res) => {
  const { text, category } = req.body;
  if (!text) return res.status(400).json({ error: "No text." });
  try {
    const system = `You are an editor for The Walleye Wire, Port Clinton Ohio. Format raw notes into a polished news story. Return ONLY a single JSON object: headline, category (Community/Local Government/Weather/General), source_tag (same), summary, body (3-5 sentences), story_date (May 1 2026), source_name ("Community Submission"), is_council (boolean), council_votes (array or []).`;
    const raw = await callClaude([{ role: "user", content: `Category: ${category || "Community"}\n\n${text}` }], system);
    const s = parseObj(raw);
    if (!s?.headline) return res.status(422).json({ error: "Could not format." });
    const r = db.prepare("INSERT INTO stories (headline,category,source_tag,summary,body,story_date,source_name,is_council,council_votes) VALUES (?,?,?,?,?,?,?,?,?)").run(s.headline, s.category, s.source_tag || s.category, s.summary, s.body, s.story_date, s.source_name, s.is_council ? 1 : 0, JSON.stringify(s.council_votes || []));
    res.json({ id: r.lastInsertRowid });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post("/api/stories/fetch", requireAdmin, async (req, res) => {
  try { res.json({ added: await fetchGeneralNews() }); } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post("/api/gov/fetch", requireAdmin, async (req, res) => {
  try { res.json(await fetchAllGovDocs()); } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── Events ─────────────────────────────────────────────────────────────────────
app.get("/api/events", (req, res) => {
  const q = req.query.all === "1"
    ? db.prepare("SELECT * FROM events ORDER BY event_date ASC").all()
    : db.prepare("SELECT * FROM events WHERE approved=1 AND event_date >= date('now') ORDER BY event_date ASC LIMIT 60").all();
  res.json(q);
});

app.post("/api/events/submit", (req, res) => {
  const { title, event_date, event_time, location, description, submitted_by } = req.body;
  if (!title || !event_date) return res.status(400).json({ error: "Title and date required." });
  const r = db.prepare("INSERT INTO events (title,event_date,event_time,location,description,submitted_by,source,approved) VALUES (?,?,?,?,?,?,?,0)").run(title, event_date, event_time || "", location || "", description || "", submitted_by || "Anonymous", "Community");
  res.json({ id: r.lastInsertRowid, pending: true });
});

app.post("/api/events/add", requireAdmin, (req, res) => {
  const { title, event_date, event_time, location, description, source } = req.body;
  if (!title || !event_date) return res.status(400).json({ error: "Title and date required." });
  const r = db.prepare("INSERT INTO events (title,event_date,event_time,location,description,source,approved) VALUES (?,?,?,?,?,?,1)").run(title, event_date, event_time || "", location || "", description || "", source || "Admin");
  res.json({ id: r.lastInsertRowid });
});

app.post("/api/events/approve/:id", requireAdmin, (req, res) => {
  db.prepare("UPDATE events SET approved=1 WHERE id=?").run(req.params.id);
  res.json({ ok: true });
});

app.delete("/api/events/:id", requireAdmin, (req, res) => {
  db.prepare("DELETE FROM events WHERE id=?").run(req.params.id);
  res.json({ ok: true });
});

// ── Fetch functions ────────────────────────────────────────────────────────────
async function fetchGeneralNews() {
  console.log("[News] Fetching general news...");
  const system = `You are a news editor for The Walleye Wire, Port Clinton Ohio. Search the web for recent community news, tourism, business, and weather stories about Port Clinton OH and Ottawa County OH. Do NOT include city council or government stories.

Return ONLY a JSON array of 3-5 story objects. Each MUST include:
- headline (string)
- category: one of Community, Weather, General
- source_tag: same as category
- summary: 1-2 sentence teaser
- body: 3-4 sentences of article content
- story_date: date in format Month D YYYY
- source_name: publication or website name
- source_url: FULL URL of the original article — REQUIRED. Only include stories where you have the real URL.
- is_council: false
- council_votes: []

IMPORTANT: source_url is mandatory. Only include stories where you have the actual URL. Do not invent URLs.`;

  const raw = await callClaude([{ role: "user", content: "Find the latest news from Port Clinton Ohio and Ottawa County — community, tourism, business, weather. Include the full source URL for every story." }], system, true);
  const stories = parseArr(raw);
  if (!stories.length) return 0;
  const valid = stories.filter(s => s.source_url && s.source_url.startsWith("http"));
  if (!valid.length) { console.log("[News] No stories with valid source URLs."); return 0; }
  const ins = db.prepare("INSERT INTO stories (headline,category,source_tag,summary,body,story_date,source_name,source_url,is_council,council_votes) VALUES (?,?,?,?,?,?,?,?,0,'[]')");
  db.transaction(items => items.forEach(s => ins.run(s.headline, s.category || "General", s.source_tag || s.category || "General", s.summary, s.body, s.story_date, s.source_name, s.source_url)))(valid);
  console.log(`[News] Added ${valid.length} stories with source URLs.`);
  return valid.length;
}

// ── City Council — only gov source ────────────────────────────────────────────
// Scrapes portclinton.com document center for council PDFs (ordinances + minutes)
// On first run (backfill=true) processes all docs from Jan 2026 onward
// On subsequent runs processes only newly seen docs (up to 5 at a time)
// Always stores the actual PDF URL as source_url on every story

async function fetchAllGovDocs({ backfill = false } = {}) {
  return { portclinton: await fetchPortClintonDocs({ backfill }) };
}

async function fetchPortClintonDocs({ backfill = false } = {}) {
  console.log(`[CityCouncil] Fetching docs (backfill=${backfill})...`);
  try {
    const html = await (await fetch("https://www.portclinton.com/document_center/index.php")).text();

    // Extract all PDF links that relate to council business
    const allMatches = [...html.matchAll(/href="([^"]+\.pdf[^"]*)"/gi)]
      .map(m => {
        const u = m[1];
        return u.startsWith("http") ? u : "https://www.portclinton.com" + u;
      })
      .filter(u => /ordinance|minutes|council|resolution/i.test(u));

    const unique = [...new Set(allMatches)];

    // For backfill: only include docs dated Jan 2026 or later based on URL text
    // For normal run: only unseen docs
    let toProcess;
    if (backfill) {
      // Filter by year in URL — 2026 docs contain "2026" in the filename
      toProcess = unique.filter(u => {
        // Include if URL contains 2026 or the filename suggests Jan 2026+
        return /2026/i.test(u) || /january.*2026|february.*2026|march.*2026|april.*2026/i.test(decodeURIComponent(u));
      }).filter(u => !db.prepare("SELECT url FROM seen_docs WHERE url=?").get(u));
      console.log(`[CityCouncil] Backfill: found ${toProcess.length} 2026 docs to process.`);
    } else {
      toProcess = unique
        .filter(u => !db.prepare("SELECT url FROM seen_docs WHERE url=?").get(u))
        .slice(0, 5); // process max 5 at a time on normal runs
    }

    if (!toProcess.length) {
      console.log("[CityCouncil] No new docs found.");
      return { added: 0 };
    }

    // Process in batches of 5 to avoid overwhelming the AI
    let totalAdded = 0;
    const batchSize = 5;
    for (let i = 0; i < toProcess.length; i += batchSize) {
      const batch = toProcess.slice(i, i + batchSize);
      const added = await processCouncilBatch(batch);
      totalAdded += added;
      // Mark as seen regardless of whether we got stories (avoids reprocessing)
      batch.forEach(u => db.prepare("INSERT OR IGNORE INTO seen_docs (url) VALUES (?)").run(u));
      // Small delay between batches to be polite
      if (i + batchSize < toProcess.length) await new Promise(r => setTimeout(r, 2000));
    }

    console.log(`[CityCouncil] Total added: ${totalAdded}`);
    return { added: totalAdded };
  } catch (e) {
    console.error("[CityCouncil] Error:", e.message);
    return { added: 0, error: e.message };
  }
}

async function processCouncilBatch(urls) {
  const system = `You are a local government reporter for The Walleye Wire in Port Clinton, Ohio.
You will be given URLs to PDF documents from the Port Clinton city website — these are ordinances, resolutions, and meeting minutes from the Port Clinton City Council.

Fetch and read each document, then return a JSON array with one story object per document.

Each story object must have:
- headline: plain English title of what was decided or discussed (e.g. "Council Votes to Sell City Hall to Ottawa County for $400,000")
- category: "Local Government"
- source_tag: "City Council"
- summary: 1-2 sentences in plain English — what happened and why it matters to Port Clinton residents
- body: 3-5 sentences explaining the decision in plain English. Avoid legal jargon. If it's an ordinance, explain what it actually does in practice. Include vote counts if available.
- story_date: the date of the meeting or ordinance in format "Month D, YYYY" (e.g. "April 28, 2026")
- source_name: "Port Clinton City Council"
- source_url: MUST be the exact PDF URL provided — do not change or omit this
- is_council: true
- council_votes: array of objects {motion: "description of what was voted on", vote: "PASSED" or "FAILED" or "TABLED"} — include all votes found in the document

IMPORTANT RULES:
- Write for a general audience — no legalese
- source_url must be the exact URL of the PDF you read
- If a document is routine (e.g. just approving minutes with no notable action), still include it but keep it brief
- story_date must come from the actual document, not today's date
- Return ONLY the JSON array, no markdown, no explanation`;

  try {
    const urlList = urls.map((u, i) => `${i + 1}. ${u}`).join("\n");
    const raw = await callClaude(
      [{ role: "user", content: `Please fetch and summarize these Port Clinton City Council documents. Make sure source_url matches each document's URL exactly:\n\n${urlList}` }],
      system, true
    );
    const stories = parseArr(raw);
    if (!stories.length) return 0;

    const ins = db.prepare("INSERT INTO stories (headline,category,source_tag,summary,body,story_date,source_name,source_url,is_council,council_votes,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)");

    let added = 0;
    stories.forEach(s => {
      // Skip if we already have this exact PDF
      const exists = db.prepare("SELECT id FROM stories WHERE source_url=?").get(s.source_url || "");
      if (exists) return;

      // Ensure source_url is one of the URLs we actually sent — prevents hallucination
      const validUrl = urls.find(u => s.source_url && (s.source_url === u || u.includes(s.source_url) || s.source_url.includes(u.split("/").pop().split("?")[0])));
      const finalUrl = validUrl || urls[0]; // fallback to first URL in batch if mismatch

      // Parse story_date into a unix timestamp for correct sorting (newest first)
      let createdAt = Math.floor(Date.now() / 1000);
      try {
        const parsed = new Date(s.story_date);
        if (!isNaN(parsed.getTime())) createdAt = Math.floor(parsed.getTime() / 1000);
      } catch {}

      ins.run(
        s.headline,
        "Local Government",
        "City Council",
        s.summary,
        s.body,
        s.story_date,
        "Port Clinton City Council",
        finalUrl, // always a real PDF URL
        1,
        JSON.stringify(s.council_votes || []),
        createdAt // use meeting date for sort order so newest meetings appear first
      );
      added++;
    });

    console.log(`[CityCouncil] Batch processed: ${added} stories added.`);
    return added;
  } catch (e) {
    console.error("[CityCouncil] Batch error:", e.message);
    return 0;
  }
}

async function fetchCalendarEvents() {
  console.log("[Calendar] Fetching events...");
  try {
    const system = `Events editor for The Walleye Wire, Port Clinton Ohio. Search for upcoming events on lakeerie.com (Lake Erie Shores & Islands) and portclinton.com/calendar.php. Return a JSON array of upcoming events: title, event_date (YYYY-MM-DD), event_time, location, description (1-2 sentences), source ("Lake Erie Shores & Islands" or "City of Port Clinton"). Return ONLY the JSON array.`;
    const raw = await callClaude([{ role: "user", content: "Find upcoming public events in Port Clinton Ohio from the Lake Erie Shores & Islands website and City of Port Clinton calendar." }], system, true);
    const events = parseArr(raw);
    events.forEach(e => {
      if (!db.prepare("SELECT id FROM events WHERE title=? AND event_date=?").get(e.title, e.event_date))
        db.prepare("INSERT INTO events (title,event_date,event_time,location,description,source,approved) VALUES (?,?,?,?,?,?,1)").run(e.title, e.event_date, e.event_time || "", e.location || "Port Clinton, OH", e.description || "", e.source || "Web");
    });
    console.log(`[Calendar] Processed ${events.length} events.`);
  } catch (e) { console.error("[Calendar]", e.message); }
}

// ── Cron ───────────────────────────────────────────────────────────────────────
cron.schedule("0 */8 * * *", () => fetchGeneralNews().catch(console.error));
cron.schedule("0 7 * * *", () => fetchAllGovDocs().catch(console.error));
cron.schedule("0 8 * * *", () => fetchCalendarEvents().catch(console.error));
cron.schedule("0 * * * *", () => refreshWeather().catch(console.error));

// ── Start ──────────────────────────────────────────────────────────────────────
app.listen(PORT, async () => {
  console.log(`\n🐟 The Walleye Wire running on port ${PORT}`);

  // Small delay to let the server stabilize before kicking off fetches
  setTimeout(async () => {
    await refreshWeather();
    await fetchCalendarEvents();

    // One-time backfill: pull all 2026 City Council docs on first ever run
    const backfillDone = db.prepare("SELECT url FROM seen_docs WHERE url='__backfill_2026_done__'").get();
    if (!backfillDone) {
      console.log("[Startup] Running one-time City Council backfill from Jan 2026...");
      await fetchPortClintonDocs({ backfill: true });
      db.prepare("INSERT OR IGNORE INTO seen_docs (url) VALUES ('__backfill_2026_done__')").run();
      console.log("[Startup] Backfill complete.");
    } else {
      console.log("[Startup] Backfill already done, skipping.");
    }
  }, 2000);
});
