const express = require("express");
const fetch = require("node-fetch");
const path = require("path");
const cron = require("node-cron");
const pdfParse = require("pdf-parse");
const initSqlJs = require("sql.js");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "walleye2025";
const ANTHROPIC_KEY = process.env.ANTHROPIC_API_KEY || "";
const DB_PATH = path.join(__dirname, "walleye.db");

// ── Database (sql.js — pure JS, no native compilation needed) ─────────────────
let db;
const SQL_SCHEMA = `
  CREATE TABLE IF NOT EXISTS stories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    headline TEXT NOT NULL,
    category TEXT NOT NULL,
    source_tag TEXT DEFAULT 'General',
    summary TEXT,
    body TEXT,
    story_date TEXT,
    source_name TEXT,
    source_url TEXT,
    is_council INTEGER DEFAULT 0,
    council_votes TEXT DEFAULT '[]',
    created_at INTEGER DEFAULT 0
  );
  CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    event_date TEXT NOT NULL,
    event_time TEXT,
    location TEXT,
    description TEXT,
    submitted_by TEXT,
    source TEXT DEFAULT 'Community',
    approved INTEGER DEFAULT 0,
    created_at INTEGER DEFAULT 0
  );
  CREATE TABLE IF NOT EXISTS seen_docs (
    url TEXT PRIMARY KEY,
    seen_at INTEGER DEFAULT 0
  );
  CREATE TABLE IF NOT EXISTS weather_cache (
    id INTEGER PRIMARY KEY,
    data TEXT DEFAULT '{}',
    updated_at INTEGER DEFAULT 0
  );
`;

async function initDb() {
  const SQL = await initSqlJs();
  if (fs.existsSync(DB_PATH)) {
    const fileBuffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(fileBuffer);
  } else {
    db = new SQL.Database();
  }
  db.run(SQL_SCHEMA);
  db.run("INSERT OR IGNORE INTO weather_cache (id, data, updated_at) VALUES (1, '{}', 0)");
  saveDb();
  console.log("[DB] Initialized.");
}

// sql.js is in-memory — we persist to disk after every write
function saveDb() {
  try {
    const data = db.export();
    fs.writeFileSync(DB_PATH, Buffer.from(data));
  } catch (e) {
    console.error("[DB] Save error:", e.message);
  }
}

// ── DB helpers — mimic better-sqlite3 API ────────────────────────────────────
function dbAll(sql, params = []) {
  try {
    const stmt = db.prepare(sql);
    stmt.bind(params);
    const rows = [];
    while (stmt.step()) rows.push(stmt.getAsObject());
    stmt.free();
    return rows;
  } catch (e) { console.error("[DB] Query error:", sql, e.message); return []; }
}

function dbGet(sql, params = []) {
  const rows = dbAll(sql, params);
  return rows[0] || null;
}

function dbRun(sql, params = []) {
  try {
    db.run(sql, params);
    saveDb();
    return { lastInsertRowid: db.exec("SELECT last_insert_rowid()")[0]?.values[0][0] };
  } catch (e) { console.error("[DB] Run error:", sql, e.message); return {}; }
}

// ── Middleware ────────────────────────────────────────────────────────────────
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

function requireAdmin(req, res, next) {
  if (req.headers["x-admin-password"] !== ADMIN_PASSWORD)
    return res.status(401).json({ error: "Unauthorized" });
  next();
}

// ── Claude API ────────────────────────────────────────────────────────────────
async function callClaude(messages, system, useWebSearch = false) {
  const tools = useWebSearch ? [{ type: "web_search_20250305", name: "web_search" }] : undefined;
  let msgs = [...messages];
  for (let i = 0; i < 8; i++) {
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": ANTHROPIC_KEY,
        "anthropic-version": "2023-06-01",
        "anthropic-beta": "web-search-2025-03-05",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 2000,
        system,
        messages: msgs,
        ...(tools ? { tools } : {}),
      }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error?.message || "Claude API error");
    const text = data.content.filter(b => b.type === "text").map(b => b.text).join("\n");
    if (data.stop_reason === "end_turn") return text;
    if (data.stop_reason === "tool_use") {
      const tu = data.content.filter(b => b.type === "tool_use");
      msgs = [
        ...msgs,
        { role: "assistant", content: data.content },
        { role: "user", content: tu.map(t => ({ type: "tool_result", tool_use_id: t.id, content: "Search executed." })) },
      ];
      continue;
    }
    if (text) return text;
    break;
  }
  throw new Error("No response from Claude.");
}

function parseArr(raw) {
  try {
    const c = raw.replace(/```json|```/g, "").trim();
    return JSON.parse(c.slice(c.indexOf("["), c.lastIndexOf("]") + 1));
  } catch { return []; }
}

function parseObj(raw) {
  try {
    const c = raw.replace(/```json|```/g, "").trim();
    return JSON.parse(c.slice(c.indexOf("{"), c.lastIndexOf("}") + 1));
  } catch { return null; }
}

// ── PDF extraction (server-side, no Claude needed) ───────────────────────────
async function extractPdfText(url) {
  try {
    console.log(`[PDF] Downloading: ${url}`);
    const res = await fetch(url, {
      headers: { "User-Agent": "Mozilla/5.0 (compatible; WalleyeWireBot/1.0)" },
      timeout: 20000,
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const buffer = await res.buffer();
    const parsed = await pdfParse(buffer);
    const text = parsed.text.trim();
    console.log(`[PDF] Extracted ${text.length} chars from ${url}`);
    return text;
  } catch (e) {
    console.error(`[PDF] Failed to extract ${url}:`, e.message);
    return null;
  }
}

// ── Weather ───────────────────────────────────────────────────────────────────
async function refreshWeather() {
  try {
    const url = "https://api.open-meteo.com/v1/forecast?latitude=41.5134&longitude=-82.9379&current=temperature_2m,weathercode,windspeed_10m,relativehumidity_2m&daily=temperature_2m_max,temperature_2m_min,weathercode,precipitation_sum&temperature_unit=fahrenheit&wind_speed_unit=mph&precipitation_unit=inch&timezone=America%2FNew_York&forecast_days=5";
    const r = await fetch(url);
    const data = await r.json();
    dbRun("UPDATE weather_cache SET data=?, updated_at=? WHERE id=1", [JSON.stringify(data), Math.floor(Date.now() / 1000)]);
    console.log("[Weather] Updated.");
  } catch (e) { console.error("[Weather]", e.message); }
}

app.get("/api/weather", async (req, res) => {
  const row = dbGet("SELECT * FROM weather_cache WHERE id=1");
  const age = Math.floor(Date.now() / 1000) - (row?.updated_at || 0);
  if (age > 3600 || !row?.data || row.data === "{}") await refreshWeather();
  const fresh = dbGet("SELECT data FROM weather_cache WHERE id=1");
  try { res.json(JSON.parse(fresh?.data || "{}")); } catch { res.json({}); }
});

// ── Stories API ───────────────────────────────────────────────────────────────
app.get("/api/stories", (req, res) => {
  const { category } = req.query;
  const rows = category && category !== "All"
    ? dbAll("SELECT * FROM stories WHERE category=? ORDER BY created_at DESC LIMIT 100", [category])
    : dbAll("SELECT * FROM stories ORDER BY created_at DESC LIMIT 100");
  res.json(rows.map(r => ({ ...r, council_votes: JSON.parse(r.council_votes || "[]") })));
});

app.delete("/api/stories/:id", requireAdmin, (req, res) => {
  dbRun("DELETE FROM stories WHERE id=?", [req.params.id]);
  res.json({ ok: true });
});

app.post("/api/stories/submit", requireAdmin, async (req, res) => {
  const { text, category } = req.body;
  if (!text) return res.status(400).json({ error: "No text." });
  try {
    const system = `You are an editor for The Walleye Wire, Port Clinton Ohio. Format raw notes into a polished news story. Return ONLY a single JSON object: headline, category (Community/Local Government/Weather/General), source_tag (same as category), summary, body (3-5 sentences), story_date (today's date as Month D YYYY), source_name ("Community Submission"), source_url (""), is_council (boolean), council_votes (array or []).`;
    const raw = await callClaude([{ role: "user", content: `Category: ${category || "Community"}\n\n${text}` }], system);
    const s = parseObj(raw);
    if (!s?.headline) return res.status(422).json({ error: "Could not format story." });
    const result = dbRun(
      "INSERT INTO stories (headline,category,source_tag,summary,body,story_date,source_name,source_url,is_council,council_votes,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
      [s.headline, s.category, s.source_tag || s.category, s.summary, s.body, s.story_date, s.source_name, s.source_url || "", s.is_council ? 1 : 0, JSON.stringify(s.council_votes || []), Math.floor(Date.now() / 1000)]
    );
    res.json({ id: result.lastInsertRowid });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post("/api/stories/fetch", requireAdmin, async (req, res) => {
  try { res.json({ added: await fetchGeneralNews() }); }
  catch (e) { res.status(500).json({ error: e.message }); }
});

app.post("/api/gov/fetch", requireAdmin, async (req, res) => {
  try { res.json(await fetchAllGovDocs()); }
  catch (e) { res.status(500).json({ error: e.message }); }
});

// ── Events API ────────────────────────────────────────────────────────────────
app.get("/api/events", (req, res) => {
  const rows = req.query.all === "1"
    ? dbAll("SELECT * FROM events ORDER BY event_date ASC")
    : dbAll("SELECT * FROM events WHERE approved=1 AND event_date >= date('now') ORDER BY event_date ASC LIMIT 60");
  res.json(rows);
});

app.post("/api/events/submit", (req, res) => {
  const { title, event_date, event_time, location, description, submitted_by } = req.body;
  if (!title || !event_date) return res.status(400).json({ error: "Title and date required." });
  const r = dbRun(
    "INSERT INTO events (title,event_date,event_time,location,description,submitted_by,source,approved,created_at) VALUES (?,?,?,?,?,?,?,0,?)",
    [title, event_date, event_time || "", location || "", description || "", submitted_by || "Anonymous", "Community", Math.floor(Date.now() / 1000)]
  );
  res.json({ id: r.lastInsertRowid, pending: true });
});

app.post("/api/events/add", requireAdmin, (req, res) => {
  const { title, event_date, event_time, location, description, source } = req.body;
  if (!title || !event_date) return res.status(400).json({ error: "Title and date required." });
  const r = dbRun(
    "INSERT INTO events (title,event_date,event_time,location,description,source,approved,created_at) VALUES (?,?,?,?,?,?,1,?)",
    [title, event_date, event_time || "", location || "", description || "", source || "Admin", Math.floor(Date.now() / 1000)]
  );
  res.json({ id: r.lastInsertRowid });
});

app.post("/api/events/approve/:id", requireAdmin, (req, res) => {
  dbRun("UPDATE events SET approved=1 WHERE id=?", [req.params.id]);
  res.json({ ok: true });
});

app.delete("/api/events/:id", requireAdmin, (req, res) => {
  dbRun("DELETE FROM events WHERE id=?", [req.params.id]);
  res.json({ ok: true });
});

// ── General news fetch ────────────────────────────────────────────────────────
async function fetchGeneralNews() {
  console.log("[News] Fetching general news...");
  const system = `You are a news editor for The Walleye Wire, Port Clinton Ohio. Search the web for recent community news, tourism, business, and weather stories about Port Clinton OH and Ottawa County OH. Do NOT include city council or government stories.

Return ONLY a JSON array of 3-5 story objects. Each MUST include:
- headline (string)
- category: one of Community, Weather, General
- source_tag: same as category
- summary: 1-2 sentence teaser
- body: 3-4 sentences of article content
- story_date: date in format Month D YYYY
- source_name: publication or website name
- source_url: FULL URL of the original article — REQUIRED. Only include stories where you have the real URL. Do not invent URLs.
- is_council: false
- council_votes: []`;

  const raw = await callClaude(
    [{ role: "user", content: "Find the latest news from Port Clinton Ohio and Ottawa County — community, tourism, business, weather. Include the full source URL for every story." }],
    system, true
  );
  const stories = parseArr(raw);
  if (!stories.length) return 0;

  const valid = stories.filter(s => s.source_url && s.source_url.startsWith("http"));
  if (!valid.length) { console.log("[News] No stories with valid source URLs."); return 0; }

  let added = 0;
  valid.forEach(s => {
    const exists = dbGet("SELECT id FROM stories WHERE source_url=?", [s.source_url]);
    if (!exists) {
      dbRun(
        "INSERT INTO stories (headline,category,source_tag,summary,body,story_date,source_name,source_url,is_council,council_votes,created_at) VALUES (?,?,?,?,?,?,?,?,0,'[]',?)",
        [s.headline, s.category || "General", s.source_tag || s.category || "General", s.summary, s.body, s.story_date, s.source_name, s.source_url, Math.floor(Date.now() / 1000)]
      );
      added++;
    }
  });

  console.log(`[News] Added ${added} stories.`);
  return added;
}

// ── City Council — PDF extraction + AI summarization ─────────────────────────
async function fetchAllGovDocs({ backfill = false } = {}) {
  return { portclinton: await fetchPortClintonDocs({ backfill }) };
}

async function fetchPortClintonDocs({ backfill = false } = {}) {
  console.log(`[CityCouncil] Fetching docs (backfill=${backfill})...`);
  try {
    const res = await fetch("https://www.portclinton.com/document_center/index.php");
    const html = await res.text();

    // Extract all PDF links relating to council business
    const allMatches = [...html.matchAll(/href="([^"]+\.pdf[^"]*)"/gi)]
      .map(m => {
        const u = m[1];
        return u.startsWith("http") ? u : "https://www.portclinton.com" + u;
      })
      .filter(u => /ordinance|minutes|council|resolution/i.test(u));

    const unique = [...new Set(allMatches)];

    let toProcess;
    if (backfill) {
      toProcess = unique
        .filter(u => /2026/i.test(u))
        .filter(u => !dbGet("SELECT url FROM seen_docs WHERE url=?", [u]));
      console.log(`[CityCouncil] Backfill: ${toProcess.length} 2026 docs to process.`);
    } else {
      toProcess = unique
        .filter(u => !dbGet("SELECT url FROM seen_docs WHERE url=?", [u]))
        .slice(0, 5);
    }

    if (!toProcess.length) {
      console.log("[CityCouncil] No new docs.");
      return { added: 0 };
    }

    let totalAdded = 0;
    const batchSize = 3; // smaller batches since we're now extracting PDF text too
    for (let i = 0; i < toProcess.length; i += batchSize) {
      const batch = toProcess.slice(i, i + batchSize);
      const added = await processCouncilBatch(batch);
      totalAdded += added;
      batch.forEach(u => dbRun("INSERT OR IGNORE INTO seen_docs (url, seen_at) VALUES (?,?)", [u, Math.floor(Date.now() / 1000)]));
      if (i + batchSize < toProcess.length) await new Promise(r => setTimeout(r, 2000));
    }

    console.log(`[CityCouncil] Total added: ${totalAdded}`);
    return { added: totalAdded };
  } catch (e) {
    console.error("[CityCouncil] Error:", e.message);
    return { added: 0, error: e.message };
  }
}

async function processCouncilBatch(urls) {
  // Step 1: Extract text from each PDF server-side
  const docs = [];
  for (const url of urls) {
    const text = await extractPdfText(url);
    if (text && text.length > 100) {
      docs.push({ url, text: text.slice(0, 6000) }); // cap at 6000 chars per doc to stay within token limits
    } else {
      console.log(`[CityCouncil] Skipping ${url} — could not extract text.`);
      // Still mark as seen so we don't retry endlessly
    }
  }

  if (!docs.length) return 0;

  // Step 2: Send extracted text to Claude for summarization — no web search needed
  const system = `You are a local government reporter for The Walleye Wire in Port Clinton, Ohio.
You will be given the extracted text content of PDF documents from the Port Clinton City Council — ordinances, resolutions, and meeting minutes.

For each document, return one story object in a JSON array.

Each story object must have:
- headline: plain English title (e.g. "Council Approves $2M Road Resurfacing Contract")
- category: "Local Government"
- source_tag: "City Council"
- summary: 1-2 sentences in plain English — what happened and why it matters to residents
- body: 3-5 sentences in plain English. No legal jargon. If it's an ordinance, explain what it does in practice. Include vote counts.
- story_date: the date of the meeting or ordinance in format "Month D, YYYY"
- source_name: "Port Clinton City Council"
- source_url: the URL provided for that document (included in the document header below)
- is_council: true
- council_votes: array of {motion, vote} — vote must be "PASSED", "FAILED", or "TABLED"

Return ONLY the JSON array, no markdown.`;

  const docContent = docs.map((d, i) =>
    `=== DOCUMENT ${i + 1} ===\nSOURCE_URL: ${d.url}\n\n${d.text}`
  ).join("\n\n");

  try {
    // No web search needed — we already have the text
    const raw = await callClaude(
      [{ role: "user", content: `Please summarize these Port Clinton City Council documents in plain English:\n\n${docContent}` }],
      system, false
    );

    const stories = parseArr(raw);
    if (!stories.length) return 0;

    let added = 0;
    stories.forEach(s => {
      const exists = dbGet("SELECT id FROM stories WHERE source_url=?", [s.source_url || ""]);
      if (exists) return;

      // Validate source_url is one we actually sent
      const validUrl = docs.find(d => d.url === s.source_url)?.url || docs[0]?.url;

      let createdAt = Math.floor(Date.now() / 1000);
      try {
        const parsed = new Date(s.story_date);
        if (!isNaN(parsed.getTime())) createdAt = Math.floor(parsed.getTime() / 1000);
      } catch {}

      dbRun(
        "INSERT INTO stories (headline,category,source_tag,summary,body,story_date,source_name,source_url,is_council,council_votes,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
        [s.headline, "Local Government", "City Council", s.summary, s.body, s.story_date, "Port Clinton City Council", validUrl, 1, JSON.stringify(s.council_votes || []), createdAt]
      );
      added++;
    });

    console.log(`[CityCouncil] Batch: ${added} stories added.`);
    return added;
  } catch (e) {
    console.error("[CityCouncil] Summarize error:", e.message);
    return 0;
  }
}

// ── Calendar fetch ────────────────────────────────────────────────────────────
async function fetchCalendarEvents() {
  console.log("[Calendar] Fetching events...");
  try {
    const system = `Events editor for The Walleye Wire, Port Clinton Ohio. Search for upcoming events on lakeerie.com (Lake Erie Shores & Islands) and portclinton.com. Return a JSON array of upcoming events: title, event_date (YYYY-MM-DD), event_time, location, description (1-2 sentences), source ("Lake Erie Shores & Islands" or "City of Port Clinton"). Return ONLY the JSON array.`;
    const raw = await callClaude(
      [{ role: "user", content: "Find upcoming public events in Port Clinton Ohio from the Lake Erie Shores & Islands website and City of Port Clinton." }],
      system, true
    );
    const events = parseArr(raw);
    let added = 0;
    events.forEach(e => {
      if (!dbGet("SELECT id FROM events WHERE title=? AND event_date=?", [e.title, e.event_date])) {
        dbRun(
          "INSERT INTO events (title,event_date,event_time,location,description,source,approved,created_at) VALUES (?,?,?,?,?,?,1,?)",
          [e.title, e.event_date, e.event_time || "", e.location || "Port Clinton, OH", e.description || "", e.source || "Web", Math.floor(Date.now() / 1000)]
        );
        added++;
      }
    });
    console.log(`[Calendar] Added ${added} events.`);
  } catch (e) { console.error("[Calendar]", e.message); }
}

// ── Cron ──────────────────────────────────────────────────────────────────────
cron.schedule("0 */8 * * *", () => fetchGeneralNews().catch(console.error));
cron.schedule("0 7 * * *", () => fetchAllGovDocs().catch(console.error));
cron.schedule("0 8 * * *", () => fetchCalendarEvents().catch(console.error));
cron.schedule("0 * * * *", () => refreshWeather().catch(console.error));

// ── Start ─────────────────────────────────────────────────────────────────────
async function start() {
  await initDb();

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`\n🐟 The Walleye Wire running on port ${PORT}`);
  });

  // Kick off initial fetches after startup
  setTimeout(async () => {
    await refreshWeather();
    await fetchCalendarEvents();

    // One-time backfill of 2026 City Council docs
    const backfillDone = dbGet("SELECT url FROM seen_docs WHERE url='__backfill_2026_done__'");
    if (!backfillDone) {
      console.log("[Startup] Running one-time City Council backfill...");
      await fetchPortClintonDocs({ backfill: true });
      dbRun("INSERT OR IGNORE INTO seen_docs (url, seen_at) VALUES ('__backfill_2026_done__', ?)", [Math.floor(Date.now() / 1000)]);
      console.log("[Startup] Backfill complete.");
    } else {
      console.log("[Startup] Backfill already done.");
    }
  }, 3000);
}

start().catch(e => {
  console.error("Fatal startup error:", e);
  process.exit(1);
});
